import { redirect } from "next/navigation";

export default function PrivacyPolicy() {
  redirect("https://brmax.xyz/privacy");
}