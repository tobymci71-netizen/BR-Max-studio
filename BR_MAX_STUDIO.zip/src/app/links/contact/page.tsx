import { redirect } from "next/navigation";

export default function Contact() {
  redirect("https://brmax.xyz/contact");
}