import { redirect } from "next/navigation";

export default function Refund() {
  redirect("https://brmax.xyz/refund");
}