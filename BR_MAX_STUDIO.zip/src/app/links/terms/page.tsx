import { redirect } from "next/navigation";

export default function Terms() {
  redirect("https://brmax.xyz/terms");
}