export const ADMIN_PASSWORD_DELIMITER = ":";
