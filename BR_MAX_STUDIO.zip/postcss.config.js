// postcss.config.js  ✅ CommonJS syntax (Next.js expects this)
module.exports = {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};